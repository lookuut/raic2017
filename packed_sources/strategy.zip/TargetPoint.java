
public class TargetPoint {
    public Army targetArmy;
    public Point2D vector;
    public Point2D targetPoint;
    public Double maxDamageValue;
}
