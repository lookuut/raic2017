public class TargetPoint {
    public Point2D vector;
    public float maxDamageValue;
}
