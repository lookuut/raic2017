public class TargetPoint {
    public Point2D vector;
    public Point2D targetPoint;
    public float maxDamageValue;
}
