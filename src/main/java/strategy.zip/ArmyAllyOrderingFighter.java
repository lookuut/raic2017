
public class ArmyAllyOrderingFighter extends ArmyAllyOrdering {

    public ArmyAllyOrderingFighter(Integer groupId) {
        super(groupId);
    }
}
