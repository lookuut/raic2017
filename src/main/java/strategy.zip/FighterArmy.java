
public class FighterArmy extends  AllyArmy {

    public FighterArmy() {
        super();
    }
}
