public class PPFieldPoint {
    public Point2D point;
    public double value;

    public PPFieldPoint (Point2D point, double value) {
        this.point = point;
        this.value = value;
    }
}
