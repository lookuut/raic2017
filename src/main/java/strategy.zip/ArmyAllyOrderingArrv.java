public class ArmyAllyOrderingArrv extends ArmyAllyOrdering {
    public ArmyAllyOrderingArrv(Integer groupId) {
        super(groupId);
    }
}
