
public class ArmyEnemy extends Army {
    public ArmyEnemy() {
        super();
    }
}
