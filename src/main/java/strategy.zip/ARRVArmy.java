public class ARRVArmy extends AllyArmy {
}
