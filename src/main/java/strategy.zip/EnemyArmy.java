
public class EnemyArmy extends Army {
    public EnemyArmy() {
        super();
    }
}
