import model.VehicleType;

import java.util.*;

public class ArmyAlly extends Army {

    protected Integer groupId;

    /**
     * battle fields
     */
    protected BattleField battleField;

    /**
     *  PPField
     */
    protected PPField staticAerialPPField;
    protected PPField staticTerrainPPField;

    private Track track;

    public ArmyAlly(Integer groupId) {
        super();
        this.groupId = groupId;
        track = new Track();
    }

    public Track getTrack() {
        return track;
    }

    public Map<Integer, Step> getActualTrackSteps() {
        Set<VehicleType> types = getVehiclesType();

        return track.sumTracks(types, this.getLastModificateTick());
    }


    public Integer getGroupId () {
        return groupId;
    }

    public void setAerialPPField (PPField field) {
        staticAerialPPField = field;
    }

    public void setTerrainPPField (PPField field) {
        staticTerrainPPField = field;
    }

    public void init (PPField terrainField, PPField aerialField) {
        setTerrainPPField(terrainField);
        setAerialPPField(aerialField);
    }


    public Point2D searchNearestEnemy() {
        try {
            Set<VehicleType> types = getVehiclesType();

            PPField sum = new PPField(battleField.getPFieldWidth(), battleField.getPFieldHeight());

            for (VehicleType type : types) {
                sum.sumField(MyStrategy.enemyField.getDamageField(type));
            }


            Point2D minValueCell = sum.getMinValueCell();
            BattleFieldCell cell = battleField.getBattleFieldCell(minValueCell.getIntX(), minValueCell.getIntY());
            Point2D enemyCellPoint = battleField.getWorldPoint(cell.getPoint());

            if (enemyCellPoint.subtract(getForm().getAvgPoint()).magnitude() >  CustomParams.safetyDistance) {
                return enemyCellPoint.subtract(getForm().getAvgPoint());
            }
            Map<Long,SmartVehicle> enemyVehicles = cell.getVehicles((int)MyStrategy.world.getOpponentPlayer().getId() - 1);

            Map<Point2D, SmartVehicle> allyVehicles = getForm().getEdgesVehicles();
            double minDistance = Double.MAX_VALUE;
            SmartVehicle minDistanceEnemyVehicle = null;
            SmartVehicle minDistanceAllyVehicle = null;
            for (SmartVehicle enemyVehicle : enemyVehicles.values()) {
                for (SmartVehicle allyVehicle : allyVehicles.values()) {
                    double distance = allyVehicle.getPoint().distance(enemyVehicle.getPoint());
                    if (distance < minDistance) {
                        minDistanceEnemyVehicle = enemyVehicle;
                        minDistanceAllyVehicle = allyVehicle;
                        minDistance = distance;
                    }
                }
            }
            if (minDistanceEnemyVehicle == null || minDistanceAllyVehicle == null) {
                throw new Exception("cant find enemy with min distance");
            }

            double attackRange = minDistanceAllyVehicle.getAttackRange(minDistanceEnemyVehicle.isAerial());
            Point2D fromPoint = minDistanceAllyVehicle.getPoint();
            Point2D targetPoint = minDistanceEnemyVehicle.getPoint();

            Point2D targetVector = targetPoint.subtract(fromPoint);
            double targetVectorMagnitude = targetVector.magnitude();
            if (targetVectorMagnitude > attackRange) {
                targetVector = targetVector.multiply((targetVectorMagnitude - attackRange) / targetVectorMagnitude);
            }

            return targetVector;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }

    public Point2D getNuclearAttackTarget() {
        return MyStrategy.enemyField.nuclearAttackTarget();
    }

    public Point2D getNearestSafetyPointForVehicle(SmartVehicle vehicle, Point2D target) throws Exception {

        EnemyPPField damageField = MyStrategy.enemyField.getDamageField(vehicle.getType());

        LineSegment lineSegment = new LineSegment(
                damageField.getTransformedPoint(vehicle.getPoint()),
                damageField.getTransformedPoint(target)
        );

        Point2D point = damageField.getNearestSafetyPoint(vehicle.getPoint(), lineSegment);

        if (point == null) {
            point = damageField.getTransformedPoint(target);
        }

        return MyStrategy.enemyField.getNearestEnemyToVehicleInCell(vehicle, point);
    }

    public Point2D[] getNearestEnemyPointAndSafetyPoint(int safetyDistance) {
        return MyStrategy.enemyField.getNearestEnemyPointAndSafetyPoint(getForm().getAvgPoint(), safetyDistance);
    }

    public BattleField getBattleField() {
        return battleField;
    }

    public boolean onDanger() {
        return MyStrategy.enemyField.onDanger(getVehiclesType(), getForm().getAvgPoint(), CustomParams.dangerRadious) != null;
    }

    public Point2D dangerPoint() {
        return MyStrategy.enemyField.onDanger(getVehiclesType(), getForm().getAvgPoint(), CustomParams.dangerRadious);
    }

}
